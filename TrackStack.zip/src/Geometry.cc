#include "Geometry.hh"

using namespace std;

static const G4double inch=2.54*cm;

Geometry::Geometry(std::ofstream& ofsa)
{
 this->f_geom=&ofsa;
 (*f_geom) << "Hi from Geom!" << " inch " << inch << std::endl;
}

Geometry::~Geometry()
{(*f_geom) << "Bye from Geom!" << std::endl;}

G4VPhysicalVolume* Geometry::Construct()
{
        G4int ncomponents;
        G4double fraction;
	G4GeometryManager::GetInstance()->OpenGeometry();
	G4PhysicalVolumeStore::GetInstance()->Clean(); 
	G4LogicalVolumeStore::GetInstance()->Clean();
	G4SolidStore::GetInstance()->Clean();

	// Параметры мира
	world_size = 30 * m;
	nist = G4NistManager::Instance();
	world_mat = nist->FindOrBuildMaterial("G4_AIR");
	world_box = new G4Box("world_box", world_size, world_size, world_size);
	world_log = new G4LogicalVolume(world_box, world_mat, "world_log");
	world_pvpl = new G4PVPlacement(0, G4ThreeVector(0,0,0), world_log, "world_pvpl", 0, false, 0);

        vodorod = nist->FindOrBuildMaterial("G4_H");
        kislorod= nist->FindOrBuildMaterial("G4_O");
        h2o     = new G4Material("h2o",0.2*g/cm3,ncomponents=2);
        h2o->AddMaterial(vodorod,fraction=0.1);
        h2o->AddMaterial(kislorod,fraction=0.9);
        
        G4Element* H = nist->FindOrBuildElement(1);
        G4Element* C = nist->FindOrBuildElement(6);
        G4Material* det_mat = new G4Material("Stilben", 0.97*g/cm3,2);
        det_mat->AddElement(H, 12);
        det_mat->AddElement(C, 14);
        
        DE_mat = nist->FindOrBuildMaterial("G4_GLASS_PLATE");
        
        DE_mat1= nist->FindOrBuildMaterial("G4_Pb");
        
	DE1_tubs = new G4Tubs("DE1", 0. * cm, 20. * cm, 20. * cm, 0, 360*deg);
	DE1_log = new G4LogicalVolume(DE1_tubs, DE_mat,"DE_log");
	DE1_vect = G4ThreeVector(0, 0, 0);
	G4RotationMatrix* ZERO_RM = new G4RotationMatrix(0, 0, 0);
	DE1_pvpl = new G4PVPlacement(ZERO_RM, DE1_vect, DE1_log, "DetEl_pvpl", world_log, 0, false, 0);

        G4double maxStep  = 10.*mm;
        G4double maxTrack = 10.*m;
        G4double maxTime  = 1.*s;
        G4double minE     = 0.001 * MeV;
        G4double minRange = 0.1 * mm;

        fStepLimit = new G4UserLimits(maxStep,maxTrack,maxTime,minE,minRange);
        DE1_log->SetUserLimits(fStepLimit);

//        G4VisAttributes* CWhite = new G4VisAttributes(G4Colour(1, 1, 1, 0.3));
        G4VisAttributes* CGreen= new G4VisAttributes(G4Colour(0.0,1.0,0.0));
        DE1_log->SetVisAttributes(CGreen);

//      Set local electric field
//        G4bool allLocal = true;
//        DE1_log->SetFieldManager(this->fpElField->myFieldManager, allLocal);

    return new G4PVPlacement(0, G4ThreeVector(), world_log, "world_pvpl", 0, false, 0);
}
